package edu.sjsu.cs185c.here;

import edu.sjsu.cs185c.didyousee.WhosHereGrpc;
import edu.sjsu.cs185c.didyousee.GrpcGossip.GossipInfo;
import edu.sjsu.cs185c.didyousee.WhosHereGrpc.WhosHereBlockingStub;
import edu.sjsu.cs185c.didyousee.GrpcGossip;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;
import picocli.CommandLine;
import picocli.CommandLine.Command;
import picocli.CommandLine.Parameters;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.Callable;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
public class Main {
    
    public static ArrayList<GrpcGossip.GossipInfo> info = new ArrayList<>();
    public static ArrayList<String> hostPorts = new ArrayList<>();
    public static HashMap<String, WhosHereBlockingStub> stubs = new HashMap<>();
    public static int currentEpoch;
    public static String myHostPort;
    public static String myName;
    public static int myHostPortIndex;

    static class GossipImpl extends WhosHereGrpc.WhosHereImplBase {

        @Override
        public void gossip(GrpcGossip.GossipRequest request, StreamObserver<GrpcGossip.GossipResponse> responseObserver) {
            List<GrpcGossip.GossipInfo> infoList = request.getInfoList();
            addInfo(infoList);
            // increment epoch if new process is discovered (info of size 1 and epoch is 0)
            if (infoList.size() == 1 && infoList.get(0).getEpoch() == 0) {
                currentEpoch++;
                updateEpoch(currentEpoch);
            }
            var response = GrpcGossip.GossipResponse.newBuilder().setRc(0).addAllInfo(info).build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();
        }

        @Override
        public void whoareyou(edu.sjsu.cs185c.didyousee.GrpcGossip.WhoRequest request,
        io.grpc.stub.StreamObserver<edu.sjsu.cs185c.didyousee.GrpcGossip.WhoResponse> responseObserver) {
            GrpcGossip.WhoResponse response = GrpcGossip.WhoResponse.newBuilder()
                .setName(myName)
                .addAllInfo(info)
                .build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();
        }

    }

    @Command(name = "gossip", mixinStandardHelpOptions = true, description = "see who's here")
    static class Cli implements Callable<Integer> {
        @CommandLine.Parameters(index="0")
        String name;

        @CommandLine.Parameters(index="1")
        int myPort;

        @CommandLine.Parameters(index="2..*")
        List<String> initialHostPorts;

        @Override
        public Integer call() throws Exception {
            myHostPort = "172.27.17.10:" + myPort;
            myName = name;
            myHostPortIndex = 0;
            hostPorts.add(myHostPort);
            currentEpoch = 0;
            if (initialHostPorts == null) initialHostPorts = new ArrayList<>();
            if (initialHostPorts.size() == 0) currentEpoch = 1;
            var server = ServerBuilder.forPort(myPort).addService(new GossipImpl()).build();
            GrpcGossip.GossipInfo myInfo = GrpcGossip.GossipInfo.newBuilder()
                .setName(myName)
                .setHostPort(myHostPort)
                .setEpoch(currentEpoch)
                .build();
            info.add(myInfo);

            server.start();
            // server.awaitTermination();


            for (int i = 0; i < initialHostPorts.size(); i++) {
                ManagedChannel channel = ManagedChannelBuilder.forTarget(initialHostPorts.get(i)).usePlaintext().build();
                stubs.put(initialHostPorts.get(i), WhosHereGrpc.newBlockingStub(channel));
                var request = GrpcGossip.GossipRequest.newBuilder().addAllInfo(info).build();
                try {
                    stubs.get(initialHostPorts.get(i)).gossip(request);
                    GrpcGossip.GossipResponse response = stubs.get(initialHostPorts.get(i)).gossip(request);
                    List<GrpcGossip.GossipInfo> infoList = response.getInfoList();
                    addInfo(infoList);
                } catch (Exception e) {
                    // couldn't connect to process
                    // remove unresponsive process from stubs
                    stubs.remove(initialHostPorts.get(i));
                }
            }
            
            while (!server.isTerminated()) {
                int hostPortIndex = myHostPortIndex;
                int contacted = 0;
                while (contacted < 2 && hostPortIndex != -1 && hostPorts.size() > 1) {
                    // hostPort is currently me or last contacted hostPort
                    hostPortIndex++; // go to next hostPort
                    if (hostPortIndex == hostPorts.size()) hostPortIndex = 0; // wrap to beginning of list
                    else if (hostPortIndex == myHostPortIndex) break; // couldn't contact two processes
                    else {
                        // contact someone and return their hostPortIndex (or -1 if no response)
                        hostPortIndex = contact(stubs, hostPortIndex);
                        contacted++;
                    }
                }
                printInfo();
                Thread.sleep(5000);
            }
            return 0;
        }
    }

    public static void updateEpoch(int newEpoch) {
        GrpcGossip.GossipInfo myInfo = GrpcGossip.GossipInfo.newBuilder()
            .setName(myName)
            .setHostPort(myHostPort)
            .setEpoch(newEpoch)
            .build();
        info.set(myHostPortIndex, myInfo);
    }

    public static void addInfo(List<GrpcGossip.GossipInfo> infoList) {
        int highestEpoch = 0;
        for (int i = 0; i < infoList.size(); i++) { // go through new info list
            int j = 0;
            GrpcGossip.GossipInfo infoItem = infoList.get(i);
            if (!infoItem.getHostPort().equals(myHostPort)) {
                // check against my info list until the hostPort in my list either matches or is greater
                while (j < info.size() && infoItem.getHostPort().compareTo(info.get(j).getHostPort()) > 0) j++;
                if (j < info.size() && info.get(j).getHostPort().equals(infoItem.getHostPort())) {
                    if (infoItem.getEpoch() > info.get(j).getEpoch()) info.set(j, infoItem);
                } else { //new hostPort is less than that at current index j
                    info.add(j, infoItem);
                    addHostPort(infoItem.getHostPort());
                    if (myHostPortIndex >= j) myHostPortIndex++;
                }
                if (infoItem.getEpoch() > highestEpoch) {
                    highestEpoch = infoItem.getEpoch();
                    updateEpoch(highestEpoch);
                }
            }
        }

        if (info.get(myHostPortIndex).getEpoch() < highestEpoch) updateEpoch(highestEpoch);
        // increment epoch
        // if someone new joins; handle in gossip()
        // if someone leaves; handled in contact()
    }

    public static void addHostPort(String hostPort) {
        int i = 0;
        while (i < hostPorts.size() && hostPort.compareTo(hostPorts.get(i)) > 0) i++;
        hostPorts.add(i, hostPort);
        // create new stub
        ManagedChannel channel = ManagedChannelBuilder.forTarget(hostPort).usePlaintext().build();
        stubs.put(hostPort, WhosHereGrpc.newBlockingStub(channel));
    }

    public static int contact(HashMap<String, WhosHereBlockingStub> stubs, int hostPortIndex) {
        var request = GrpcGossip.GossipRequest.newBuilder().addAllInfo(info).build();
        boolean contacted = false;
        while (!contacted && hostPortIndex != myHostPortIndex) {
            try {
                var response = stubs.get(hostPorts.get(hostPortIndex)).gossip(request);
                List<GrpcGossip.GossipInfo> infoList = response.getInfoList();
                addInfo(infoList);
                contacted = true;
            } catch (Exception e) { // couldn't contact node
                // if you can't contact a node AND their epoch is current, increment epoch
                if (info.get(hostPortIndex).getEpoch() == currentEpoch) {
                    currentEpoch++;
                    updateEpoch(currentEpoch);
                }
                hostPortIndex++; // move onto next hostPort
                if (hostPortIndex == hostPorts.size()) hostPortIndex = 0; // wrap to beginning if the end was reached
                contacted = false;
            }
        }
        if (!contacted) hostPortIndex = -1;
        return hostPortIndex;
    }

    public static void printInfo() {
        System.out.println("=======");
        for (int i = 0; i < info.size(); i++) {
            System.out.print(info.get(i).getEpoch());
            System.out.print(" ");
            System.out.print(info.get(i).getHostPort());
            System.out.print(" ");
            System.out.print(info.get(i).getName());
            System.out.println();
        }
    }

    public static void main(String[] args) {
        System.exit(new CommandLine(new Cli()).execute(args));
    }
}


